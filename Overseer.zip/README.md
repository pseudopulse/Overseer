# Overseer

Adds the Overseer.

![overseer lobby screenshot][def]

[def]: https://cdn.discordapp.com/attachments/959133036815978498/1177722189395538042/032712-screenshot.png
# Credits
pseudopulse - code and implementation

smxrez - model help, playtesting

james & unmatchedpowerofthesun - playtesting

# Changelog
## 0.7.0
- release!

